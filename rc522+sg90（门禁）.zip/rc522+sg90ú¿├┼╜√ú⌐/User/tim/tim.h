#ifndef __TIM_H 
#define __TIM_H 

#include "stm32f10x.h"


void INIT_tim(void);
void NVIC_init(void);
void TIM3PWM_init(void);

#endif //__TIM_H



