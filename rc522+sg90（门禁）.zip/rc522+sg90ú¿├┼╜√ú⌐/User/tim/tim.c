#include "tim.h"
#include "./led/led.h"

void NVIC_init(void)
{
	NVIC_InitTypeDef NVIC_InitTsturt;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTsturt.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_InitTsturt.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_InitTsturt.NVIC_IRQChannelSubPriority=2;
	NVIC_InitTsturt.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitTsturt);
}

void INIT_tim(void)
{
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitTsturuct;
	//������ʱ��ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	
	//��ʱ��3��ʼ��
	TIM_TimeBaseInitTsturuct.TIM_Prescaler=10000-1;
	TIM_TimeBaseInitTsturuct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitTsturuct.TIM_Period=14400-1;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitTsturuct);
	
	//NVIC��ʼ��
	NVIC_init();
	
	//������ʱ��3�ж�
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
	
	//������ʱ��3
	TIM_Cmd(TIM3,ENABLE);
}



void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{
		GPIOB->ODR^=(1<<5);
		//GPIO_ResetBits(GPIOB, GPIO_Pin_5);
	}
	TIM_ClearFlag(TIM3,TIM_FLAG_Update);
}

