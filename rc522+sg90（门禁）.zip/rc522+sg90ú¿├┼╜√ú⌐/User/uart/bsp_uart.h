#ifndef __BSP_UART_H
#define __BSP_UART_H

#include "stm32f10x.h"
#include "stdio.h"

void uart_GPIO_Config(void);
void	UART_Sendbyte(USART_TypeDef* USART, uint16_t ch);
void UART_SendString(USART_TypeDef* USART, char* str);
void USART1_receive_str(unsigned char *str);


#endif   // __BSP_UART_H0

