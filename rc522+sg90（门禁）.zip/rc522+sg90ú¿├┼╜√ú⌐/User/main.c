#include "stm32f10x.h"
#include "led.h"
#include "pwm.h"
#include "delay.h"
#include "bsp_uart.h"
#include "rc522.h"
unsigned int i;
extern unsigned char SN[4]; //����
unsigned char SN1[5]={0XA6,0X22,0X12,0X32};
int main(void)
{
	delay_init();		//��ʱ����ʼ��
	TIM3PWM_init();		//TIM3	ch2��ʼ��
	uart_GPIO_Config();  //����1��ʼ��
	PIN_Config();   //�������ų�ʼ��
	InitRc522();	
	printf("start\r\n");
	while(1)
	{
		Readid();	
//	for(i=0;i<4;i++)
//	{
//		printf("%x",SN[i]);
//	}
		if((SN[0]==SN1[0])&&(SN[1]==SN1[1])&&(SN[2]==SN1[2])&&(SN[3]==SN1[3]))
		{
			printf("open\r\n");
			TIM_SetCompare2(TIM3, 195);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 190);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 185);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 180);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 175);
			delay_ms(1000); 
			delay_ms(1000);
			delay_ms(1000);
			delay_ms(1000);
			delay_ms(1000);
			delay_ms(1000);
			TIM_SetCompare2(TIM3, 175);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 180);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 185);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 190);
			delay_ms(100);
			TIM_SetCompare2(TIM3, 195);
			delay_ms(1000); 
			delay_ms(1000);
			delay_ms(1000);
		}
		else
		{
			printf("close\r\n");
		}
		delay_ms(1000);
		delay_ms(1000);
		delay_ms(1000);
	}

}

