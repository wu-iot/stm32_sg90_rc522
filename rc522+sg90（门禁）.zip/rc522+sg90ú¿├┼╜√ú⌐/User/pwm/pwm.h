#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h"

void TIM3PWM_init(void);

#endif

